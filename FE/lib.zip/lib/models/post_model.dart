class Post {
  final int id;
  final int categoryId;
  final String title;
  final String content;
  final String author;
  final String category;

  Post({
    required this.id,
    required this.categoryId,
    required this.title,
    required this.content,
    required this.author,
    required this.category,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'],
      categoryId: json['category_id'],
      title: json['title'],
      content: json['content'],
      author: json['author'],
      category: json['category'],
    );
  }
}