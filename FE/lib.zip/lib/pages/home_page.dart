import 'package:flutter/material.dart';
import '../models/post_model.dart';
import '../services/post_service.dart';
import 'add_post_page.dart';
import 'detail_post_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Post>> posts;

  @override
  void initState() {
    super.initState();
    refreshPosts();
  }

  void refreshPosts() {
    setState(() {
      posts = PostService.getPosts();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Blog App')),

      body: FutureBuilder<List<Post>>(
        future: posts,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final data = snapshot.data ?? [];

          if (data.isEmpty) {
            return const Center(child: Text('Belum ada artikel'));
          }

          return ListView.builder(
            itemCount: data.length,

            itemBuilder: (context, index) {
              final post = data[index];

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),

                child: ListTile(
                  title: Text(
                    post.title,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),

                  subtitle: Text('${post.category} • ${post.author}'),

                  trailing: const Icon(Icons.arrow_forward_ios, size: 16),

                  // KLIK ARTIKEL → DETAIL
                  onTap: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailPostPage(post: post),
                      ),
                    );

                    if (result == true) {
                      refreshPosts();
                    }
                  },
                ),
              );
            },
          );
        },
      ),

      // TAMBAH ARTIKEL
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddPostPage()),
          );

          refreshPosts();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
