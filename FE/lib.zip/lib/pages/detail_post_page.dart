import 'package:flutter/material.dart';
import 'package:project_rpl3/models/category_service.dart';
import '../models/post_model.dart';
import '../models/category_model.dart';
import '../services/post_service.dart';

class DetailPostPage extends StatefulWidget {
  final Post post;

  const DetailPostPage({super.key, required this.post});

  @override
  State<DetailPostPage> createState() => _DetailPostPageState();
}

class _DetailPostPageState extends State<DetailPostPage> {
  bool edit = false;

  late TextEditingController title;
  late TextEditingController content;
  late TextEditingController author;

  List<Category> categories = [];
  int? categoryId;

  @override
  void initState() {
    super.initState();

    title = TextEditingController(text: widget.post.title);
    content = TextEditingController(text: widget.post.content);
    author = TextEditingController(text: widget.post.author);
    categoryId = widget.post.categoryId;

    loadCategory();
  }

  void loadCategory() async {
    categories = await CategoryService.getCategories();
    setState(() {});
  }

  void update() async {
    await PostService.updatePost(
      id: widget.post.id,
      categoryId: categoryId!,
      title: title.text,
      content: content.text,
      author: author.text,
    );

    if (mounted) Navigator.pop(context, true);
  }

  void hapus() async {
    await PostService.deletePost(widget.post.id);

    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(edit ? 'Edit Artikel' : 'Detail Artikel'),
        actions: [
          if (!edit)
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => setState(() => edit = true),
            ),
          if (!edit)
            IconButton(icon: const Icon(Icons.delete), onPressed: hapus),
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),
        child: edit ? formEdit() : detail(),
      ),
    );
  }

  Widget detail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.post.title,
          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
        Text(widget.post.category),
        Text('Author: ${widget.post.author}'),
        const Divider(),
        Text(widget.post.content),
      ],
    );
  }

  Widget formEdit() {
    return SingleChildScrollView(
      child: Column(
        children: [
          TextField(
            controller: title,
            decoration: const InputDecoration(
              labelText: 'Judul',
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 15),

          DropdownButtonFormField<int>(
            value: categoryId,
            decoration: const InputDecoration(
              labelText: 'Kategori',
              border: OutlineInputBorder(),
            ),
            items: categories.map((c) {
              return DropdownMenuItem<int>(value: c.id, child: Text(c.name));
            }).toList(),
            onChanged: (value) {
              setState(() {
                categoryId = value;
              });
            },
          ),

          const SizedBox(height: 15),

          TextField(
            controller: author,
            decoration: const InputDecoration(
              labelText: 'Author',
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 15),

          TextField(
            controller: content,
            maxLines: 6,
            decoration: const InputDecoration(
              labelText: 'Konten',
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
              onPressed: update,
              child: const Text('Simpan'),
            ),
          ),
        ],
      ),
    );
  }
}
