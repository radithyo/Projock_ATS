import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/post_model.dart';

class PostService {
  static const String baseUrl = 'http://localhost:3000/api';

  // GET
  static Future<List<Post>> getPosts() async {
    final response = await http.get(
      Uri.parse('$baseUrl/posts'),
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      final List data = jsonData['data'];

      return data.map((item) => Post.fromJson(item)).toList();
    } else {
      throw Exception('Gagal mengambil artikel');
    }
  }

  // POST
  static Future<void> createPost({
    required int categoryId,
    required String title,
    required String content,
    required String author,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/posts'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'category_id': categoryId,
        'title': title,
        'content': content,
        'author': author,
      }),
    );

    if (response.statusCode != 201) {
      throw Exception('Gagal menambahkan artikel');
    }
  }

  // PUT
  static Future<void> updatePost({
    required int id,
    required int categoryId,
    required String title,
    required String content,
    required String author,
  }) async {
    final response = await http.put(
      Uri.parse('$baseUrl/posts/$id'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'category_id': categoryId,
        'title': title,
        'content': content,
        'author': author,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Gagal mengedit artikel');
    }
  }

  // DELETE
  static Future<void> deletePost(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/posts/$id'),
    );

    if (response.statusCode != 200) {
      throw Exception('Gagal menghapus artikel');
    }
  }
}